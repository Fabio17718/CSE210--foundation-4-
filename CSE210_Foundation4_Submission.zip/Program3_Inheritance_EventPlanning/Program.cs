using System;

namespace EventPlanningProgram;

class Event
{
    protected string _title;
    protected string _date;
    protected string _time;
    protected string _address;
    protected string _description;

    public Event(string title, string date, string time, string address, string description)
    {
        _title = title;
        _date = date;
        _time = time;
        _address = address;
        _description = description;
    }

    public virtual string GetStandardDetails() =>
        $"{_title}\n{_description}\nDate: {_date} at {_time}\nAddress: {_address}";

    public virtual string GetFullDetails() => GetStandardDetails();
    public virtual string GetShortDescription() => $"Event: {_title} on {_date}";
}

class Lecture : Event
{
    private readonly string _speaker;
    private readonly int _capacity;

    public Lecture(string title, string date, string time, string address, string description,
        string speaker, int capacity)
        : base(title, date, time, address, description)
    {
        _speaker = speaker;
        _capacity = capacity;
    }

    public override string GetFullDetails() =>
        $"{GetStandardDetails()}\nSpeaker: {_speaker}\nCapacity: {_capacity} people";

    public override string GetShortDescription() => $"Lecture: {_title} — speaker: {_speaker}";
}

class Reception : Event
{
    private readonly string _rsvpEmail;

    public Reception(string title, string date, string time, string address, string description,
        string rsvpEmail)
        : base(title, date, time, address, description)
    {
        _rsvpEmail = rsvpEmail;
    }

    public override string GetFullDetails() =>
        $"{GetStandardDetails()}\nRSVP: {_rsvpEmail}";

    public override string GetShortDescription() => $"Reception: {_title} on {_date}";
}

class OutdoorGathering : Event
{
    private readonly string _weatherPlan;

    public OutdoorGathering(string title, string date, string time, string address, string description,
        string weatherPlan)
        : base(title, date, time, address, description)
    {
        _weatherPlan = weatherPlan;
    }

    public override string GetFullDetails() =>
        $"{GetStandardDetails()}\nBad-weather plan: {_weatherPlan}";

    public override string GetShortDescription() => $"Outdoor gathering: {_title} at {_time}";
}

class Program
{
    static void Main()
    {
        Event[] events =
        {
            new Lecture("Career Skills Talk", "Nov 5", "6:00 PM", "Campus Room 101",
                "A talk about preparing for a career.", "Morgan Lee", 80),
            new Reception("Family Celebration", "Nov 8", "5:30 PM", "Community Hall",
                "A time to celebrate together.", "rsvp@example.com"),
            new OutdoorGathering("Soccer Picnic", "Nov 12", "12:00 PM", "Upper Fields",
                "Food and games outside.", "Move to the student center.")
        };

        foreach (Event item in events)
        {
            Console.WriteLine(item.GetFullDetails());
            Console.WriteLine(item.GetShortDescription());
            Console.WriteLine(new string('-', 35));
        }
    }
}
