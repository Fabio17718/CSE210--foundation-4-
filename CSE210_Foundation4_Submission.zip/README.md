# CSE 210 — Foundation 4

Four separate C# console programs demonstrating the four principles of programming with classes.

## Programs

1. **Abstraction — YouTube Videos and Comments**  
   `Video` and `Comment` classes keep the details of videos and comments organized. The `Video` class handles displaying video information and comments.

2. **Encapsulation — Online Ordering**  
   `Order`, `Product`, `Customer`, and `Address` classes manage their own data and behavior. The order calculates subtotal, shipping, and total, and displays packing and shipping labels.

3. **Inheritance — Event Planning**  
   `Lecture`, `Reception`, and `OutdoorGathering` inherit common information and behavior from `Event`. Each event type adds its own details.

4. **Polymorphism — Exercise Tracking**  
   `Running`, `Cycling`, and `Swimming` inherit from `Activity` and override methods to calculate activity distance and speed differently.

## Requirements

- .NET 8 SDK
- Visual Studio, Visual Studio Code with C# support, or the .NET CLI

## Run a program

Open a terminal in the folder for the program you want to run. For example:

```bash
cd Program1_Abstraction_YouTube
dotnet run
```

Repeat with `Program2_Encapsulation_OnlineOrdering`, `Program3_Inheritance_EventPlanning`, or `Program4_Polymorphism_ExerciseTracking`.

## GitHub submission

1. Create a new GitHub repository named `cse210-foundation4`.
2. Upload the contents of this folder (including all four program folders and this README) to the repository, or push them using Git.
3. Open the repository on GitHub and copy its URL.
4. Paste that real repository URL into the W07 Prove assignment in I-Learn.

**Important:** This folder is a project starter prepared for the assignment. Run all four programs in your own environment and review the code before submitting. The repository URL does not exist until you create the repository on your GitHub account.
