using System;
using System.Collections.Generic;

namespace YouTubeProgram;

class Comment
{
    public string Name { get; }
    public string Text { get; }

    public Comment(string name, string text)
    {
        Name = name;
        Text = text;
    }
}

class Video
{
    private readonly List<Comment> _comments = new();

    public string Title { get; }
    public string Author { get; }
    public int LengthSeconds { get; }

    public Video(string title, string author, int lengthSeconds)
    {
        Title = title;
        Author = author;
        LengthSeconds = lengthSeconds;
    }

    public void AddComment(Comment comment) => _comments.Add(comment);

    public void Display()
    {
        Console.WriteLine($"Video: {Title}");
        Console.WriteLine($"Author: {Author}");
        Console.WriteLine($"Length: {LengthSeconds} seconds");
        Console.WriteLine($"Comments ({_comments.Count}):");
        foreach (Comment comment in _comments)
            Console.WriteLine($"- {comment.Name}: {comment.Text}");
        Console.WriteLine();
    }
}

class Program
{
    static void Main()
    {
        Video first = new("Learning C#", "Fabio", 240);
        first.AddComment(new Comment("Alex", "This was helpful!"));
        first.AddComment(new Comment("Sam", "Thanks for sharing."));
        first.AddComment(new Comment("Jordan", "I learned something new."));

        Video second = new("Soccer Training Tips", "Coach Lee", 315);
        second.AddComment(new Comment("Chris", "Great tips."));
        second.AddComment(new Comment("Taylor", "I will try these drills."));

        first.Display();
        second.Display();
    }
}
