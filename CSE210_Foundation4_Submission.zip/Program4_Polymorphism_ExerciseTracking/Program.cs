using System;

namespace ExerciseTrackingProgram;

abstract class Activity
{
    protected DateTime _date;
    protected int _minutes;

    protected Activity(DateTime date, int minutes)
    {
        _date = date;
        _minutes = minutes;
    }

    public abstract double GetDistanceKm();
    public abstract double GetSpeedKph();

    public virtual double GetPaceMinutesPerKm()
    {
        double distance = GetDistanceKm();
        return distance > 0 ? _minutes / distance : 0;
    }

    public virtual string GetSummary() =>
        $"{_date:dd MMM yyyy} ({_minutes} min) - Distance: {GetDistanceKm():F2} km, " +
        $"Speed: {GetSpeedKph():F2} kph, Pace: {GetPaceMinutesPerKm():F2} min per km";
}

class Running : Activity
{
    private readonly double _distanceKm;

    public Running(DateTime date, int minutes, double distanceKm) : base(date, minutes)
        => _distanceKm = distanceKm;

    public override double GetDistanceKm() => _distanceKm;
    public override double GetSpeedKph() => _minutes > 0 ? _distanceKm / _minutes * 60 : 0;
}

class Cycling : Activity
{
    private readonly double _distanceKm;

    public Cycling(DateTime date, int minutes, double distanceKm) : base(date, minutes)
        => _distanceKm = distanceKm;

    public override double GetDistanceKm() => _distanceKm;
    public override double GetSpeedKph() => _minutes > 0 ? _distanceKm / _minutes * 60 : 0;
}

class Swimming : Activity
{
    private readonly int _laps;
    private const double PoolLengthKm = 0.05;

    public Swimming(DateTime date, int minutes, int laps) : base(date, minutes)
        => _laps = laps;

    public override double GetDistanceKm() => _laps * PoolLengthKm;
    public override double GetSpeedKph() => _minutes > 0 ? GetDistanceKm() / _minutes * 60 : 0;
}

class Program
{
    static void Main()
    {
        Activity[] activities =
        {
            new Running(new DateTime(2026, 10, 20), 30, 4.8),
            new Cycling(new DateTime(2026, 10, 21), 45, 15.0),
            new Swimming(new DateTime(2026, 10, 22), 25, 40)
        };

        Console.WriteLine("EXERCISE SUMMARY");
        foreach (Activity activity in activities)
            Console.WriteLine(activity.GetSummary());
    }
}
