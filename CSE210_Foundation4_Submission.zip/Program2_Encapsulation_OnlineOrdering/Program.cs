using System;
using System.Collections.Generic;
using System.Linq;

namespace OnlineOrderingProgram;

class Product
{
    public string Name { get; }
    public string ProductId { get; }
    public decimal Price { get; }
    public int Quantity { get; }

    public Product(string name, string productId, decimal price, int quantity)
    {
        Name = name;
        ProductId = productId;
        Price = price;
        Quantity = quantity;
    }

    public decimal GetTotal() => Price * Quantity;
}

class Address
{
    private readonly string _street;
    private readonly string _city;
    private readonly string _state;
    private readonly string _country;

    public Address(string street, string city, string state, string country)
    {
        _street = street;
        _city = city;
        _state = state;
        _country = country;
    }

    public bool IsInUnitedStates() =>
        _country.Trim().Equals("USA", StringComparison.OrdinalIgnoreCase) ||
        _country.Trim().Equals("United States", StringComparison.OrdinalIgnoreCase);

    public string GetFullAddress() => $"{_street}\n{_city}, {_state}\n{_country}";
}

class Customer
{
    public string Name { get; }
    private readonly Address _address;

    public Customer(string name, Address address)
    {
        Name = name;
        _address = address;
    }

    public string GetAddress() => _address.GetFullAddress();
    public bool LivesInUnitedStates() => _address.IsInUnitedStates();
}

class Order
{
    private readonly Customer _customer;
    private readonly List<Product> _products = new();

    public Order(Customer customer) => _customer = customer;

    public void AddProduct(Product product) => _products.Add(product);

    public decimal GetSubtotal() => _products.Sum(product => product.GetTotal());

    public decimal GetShippingCost() => _customer.LivesInUnitedStates() ? 5.00m : 35.00m;

    public decimal GetTotal() => GetSubtotal() + GetShippingCost();

    public void DisplayPackingLabel()
    {
        Console.WriteLine("PACKING LABEL");
        Console.WriteLine(_customer.GetAddress());
        Console.WriteLine("\nProducts:");
        foreach (Product product in _products)
            Console.WriteLine($"{product.Name} (ID: {product.ProductId})");
    }

    public void DisplayShippingLabel()
    {
        Console.WriteLine("SHIPPING LABEL");
        Console.WriteLine(_customer.Name);
        Console.WriteLine(_customer.GetAddress());
    }

    public void DisplayOrder()
    {
        Console.WriteLine($"\nOrder for {_customer.Name}");
        foreach (Product product in _products)
            Console.WriteLine($"{product.Name} x{product.Quantity}: ${product.GetTotal():F2}");
        Console.WriteLine($"Subtotal: ${GetSubtotal():F2}");
        Console.WriteLine($"Shipping: ${GetShippingCost():F2}");
        Console.WriteLine($"Total: ${GetTotal():F2}\n");
    }
}

class Program
{
    static void Main()
    {
        Customer customer = new("Fabio Silva",
            new Address("123 Main Street", "Rexburg", "Idaho", "USA"));

        Order order = new(customer);
        order.AddProduct(new Product("Soccer Ball", "SB01", 24.99m, 1));
        order.AddProduct(new Product("Water Bottle", "WB02", 8.50m, 2));

        order.DisplayOrder();
        order.DisplayPackingLabel();
        Console.WriteLine();
        order.DisplayShippingLabel();
    }
}
